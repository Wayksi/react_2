const productImages = import.meta.glob('@assets/product-card/*png', {
  eager: true,
  import: 'default',
});

const imageMap = Object.fromEntries(
  Object.entries(productImages).map(([path, src]) => {
    const filename = path.split('/').pop().replace('.png', '');
    return [filename, src]
  })
);

const products = [
    {
        id: 0,
        slug: "chicken-thigh",
        imageName: "chicken-thigh",
        alt: "Филе бедра цыпленка",
        name: "Филе бедра цыпленка",
        description: "Филе бедра без кожи и кости. Птица содержится в свободных птичниках, выращивается на натуральных зерновых кормах, что влияет положительно на вкус мяса. Филейная часть бедра обладает насыщенным вкусом и мясным ароматом.",
        price: "400 руб. / 700 гр.",
        specification: {
            mass: "0,7 кг. (595-805 г.).",
            term: "6 суток",
            breed: "КОББ 500.",
            origin: "Тверская область"
        },
        properties: {
            energyValue: "135 ккал./565 кДж.",
            nutritionValue: "белки - 13,8 г., жиры - 8,7 г., углеводы - 0 г.; на 100 г."
        }
    },
    {
        id: 1,
        slug: "goose-thigh",
        imageName: "goose-thigh",
        alt: "Филе бедра гуся",
        name: "Филе бедра гуся",
        description: "Филе бедра гуся - это тонко нарезанный продукт, который понравится всем любителям сырокопченых продуктов. Необычный вкус, аппетитный аромат и тонкое послевкусия отличает сырокопченого гуся от других подобных продуктов.",
        price: "400 руб. / 700 гр.",
        specification: {
            mass: "0,7 кг. (595-805 г.).",
            term: "6 суток",
            breed: "КОББ 500.",
            origin: "Тверская область"
        },
        properties: {
            energyValue: '135 ккал./565 кДж.',
            nutritionValue: "белки - 13,8 г., жиры - 8,7 г., углеводы - 0 г.; на 100 г."
        }
    },
    {
        id: 2,
        slug: "beef-thigh",
        imageName: "beef-thigh",
        alt: "Мякоть бедра говяжья",
        name: "Мякоть бедра говяжья",
        description: "Мякоть бедра - это жестковатое мясо, но очень диетическое и прекрасно подходит для поклонников здорового питания. Мясо можно запечь или потушить с овощами. Все бычки на ферме Эдуарда Васильева выращиваются на натуральном корме",
        price: "400 руб. / 700 гр.",
        specification: {
            mass: "0,7 кг. (595-805 г.).",
            term: "6 суток",
            breed: "КОББ 500.",
            origin: "Тверская область"
        },
        properties: {
            energyValue: '135 ккал./565 кДж.',
            nutritionValue: "белки - 13,8 г., жиры - 8,7 г., углеводы - 0 г.; на 100 г."
        }
    },
    {
        id: 3,
        slug: "chicken-chest",
        imageName: "beef-thigh",
        alt: "Грудка цыпленка на кости",
        name: "Грудка цыпленка на кости",
        description: "Мякоть бедра - это жестковатое мясо, но очень диетическое и прекрасно подходит для поклонников здорового питания. Мясо можно запечь или потушить с овощами. Все бычки на ферме Эдуарда Васильева выращиваются на натуральном корме",
        price: "400 руб. / 700 гр.",
        specification: {
            mass: "0,7 кг. (595-805 г.).",
            term: "6 суток",
            breed: "КОББ 500.",
            origin: "Тверская область"
        },
        properties: {
            energyValue: '135 ккал./565 кДж.',
            nutritionValue: "белки - 13,8 г., жиры - 8,7 г., углеводы - 0 г.; на 100 г."
        }
    },
    {
        id: 4,
        slug: "chicken-shin",
        imageName: 'beef-thigh',
        alt: "Голень цыпленка",
        name: "Голень цыпленка",
        description: "Мякоть бедра - это жестковатое мясо, но очень диетическое и прекрасно подходит для поклонников здорового питания. Мясо можно запечь или потушить с овощами. Все бычки на ферме Эдуарда Васильева выращиваются на натуральном корме",
        price: "400 руб. / 700 гр.",
        specification: {
            mass: "0,7 кг. (595-805 г.).",
            term: "6 суток",
            breed: "КОББ 500.",
            origin: "Тверская область"
        },
        properties: {
            energyValue: '135 ккал./565 кДж.',
            nutritionValue: "белки - 13,8 г., жиры - 8,7 г., углеводы - 0 г.; на 100 г."
        }
    }
];

const productsWithImages = products.map((product) => ({
  ...product,
  src: imageMap[product.imageName] || '',
}));

export default productsWithImages;
