export const AppRoute = {
    MAIN: "/",
    BUY: "/buy"
};
