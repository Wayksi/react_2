export { default as Img } from "./img/img";
export { default as Li } from "./li/li";
export { default as P } from "./p/p";
export { default as Section } from "./section/section";
export { default as Ul } from "./ul/ul";
